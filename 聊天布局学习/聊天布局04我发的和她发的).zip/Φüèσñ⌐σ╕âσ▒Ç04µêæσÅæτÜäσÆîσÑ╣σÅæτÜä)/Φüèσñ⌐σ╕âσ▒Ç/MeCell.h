//
//  MeCell.h
//  聊天布局
//
//  Created by 冷武橘 on 2017/8/20.
//  Copyright © 2017年 冷武橘. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Message;
@interface MeCell : UITableViewCell
@property (nonatomic, strong) Message *message;
@end
